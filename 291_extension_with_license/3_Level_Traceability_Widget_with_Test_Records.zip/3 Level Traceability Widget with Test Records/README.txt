3 Level Traceability Widget with Test Records
=============================================

- import the widget to repository 
	svn import 3 Level Traceability  http://YOURSERVER/.polarion/pages/widgets/3 Level Traceability with Test Records

	or to your project

	svn import 3 Level Traceability http://YOURSERVER/PATH/TO/YOUR/PROJECT/.polarion/pages/widgets/3 Level Traceability with Test Records

